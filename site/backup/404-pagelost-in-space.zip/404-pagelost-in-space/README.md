# 404 Page - Lost In Space

A Pen created on CodePen.io. Original URL: [https://codepen.io/salehriaz/pen/erJrZM](https://codepen.io/salehriaz/pen/erJrZM).

Coded my dribbble shot: https://dribbble.com/shots/4330167-404-Page-Lost-In-Space

Animated 404 Lost in Space Page.
CSS3 Keyframe animations used.
All the illustrations are hand-crafted in Adobe Illustrator.